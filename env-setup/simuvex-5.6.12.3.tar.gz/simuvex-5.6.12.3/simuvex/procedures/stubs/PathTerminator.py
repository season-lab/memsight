import simuvex

######################################
# Path terminator
######################################


class PathTerminator(simuvex.SimProcedure):
    NO_RET = True

    def run(self):
        return
