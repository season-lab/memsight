import simuvex

######################################
# Unresolvable Target
######################################


class UnresolvableTarget(simuvex.SimProcedure):
    NO_RET = True

    def run(self):
        return
