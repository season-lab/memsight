import simuvex

from .__isoc99_sscanf import __isoc99_sscanf

class sscanf(__isoc99_sscanf):
    pass
