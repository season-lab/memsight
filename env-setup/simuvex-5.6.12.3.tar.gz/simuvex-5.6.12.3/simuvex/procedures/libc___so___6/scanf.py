import simuvex

from .__isoc99_scanf import __isoc99_scanf

class scanf(__isoc99_scanf):
    pass
