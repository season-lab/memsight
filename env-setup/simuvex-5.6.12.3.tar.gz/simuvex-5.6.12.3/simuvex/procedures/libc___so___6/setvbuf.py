import simuvex

class setvbuf(simuvex.SimProcedure):
    def run(self, stream, buf, type_, size):
        return 0
