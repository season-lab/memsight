import simuvex

class manyargs(simuvex.SimProcedure):
    NO_RET = True

    def run(self):
        pass
